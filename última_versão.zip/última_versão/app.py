from flask import Flask
from controllers.auth import auth_bp
from controllers.main import main_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sua_chave_secreta'

app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(main_bp)

if __name__ == '__main__':
    app.run(debug=True)
