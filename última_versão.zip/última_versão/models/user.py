class User:
    users = []

    def __init__(self, username, password):
        self.username = username
        self.password = password

    @classmethod
    def add_user(cls, username, password):
        cls.users.append(User(username, password))

    @classmethod
    def find_by_username(cls, username):
        return next((user for user in cls.users if user.username == username), None)

    @classmethod
    def validate_user(cls, username, password):
        user = cls.find_by_username(username)
        return user and user.password == password
